import java.io.*;
import java.net.*;

public class Client {

    public static void main(String args[]) throws Exception {
        Socket socket = new Socket("localhost", 5000);
        BufferedReader inputVar = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        PrintStream outVar = new PrintStream(socket.getOutputStream());
        BufferedReader stdin = new BufferedReader(new InputStreamReader(System.in));
        String str;
        while (true) {
            System.out.print("Client : Enter the digit for what you want to do\n");
            System.out.print("a.I want to get a list of connect customers\n");
            System.out.print("b.I want to disconnect from the server\n");
            System.out.print("c.I want to send a message to a specific customer\n");
            System.out.print("d.I want to send a message to all customers\n");

            str = stdin.readLine();
            String  server_message="";

            if(str.equals("a"))
            {
                outVar.println(str);


            }
            else if(str.equals("b"))
            {
                System.out.println("Connection Broken.....");
                outVar.println("BYE");
                break;
            }
            else if(str.equals("c"))
            {
                System.out.println("Enter the number of the customer you wish to send the message to");

                String number= stdin.readLine();

                System.out.println("Enter the message you wish to send");
                String message= stdin.readLine();
                String mess="";
                mess+='c';
                mess+=",";
                mess+=number;
                mess+=',';
                mess+=message;

                outVar.println(mess);


            }
            else if(str.equals("d"))
            {
                System.out.println("Enter the message you wish to send to all clients");
                String message= stdin.readLine();
                message="d"+","+message;

                System.out.println(message);
                outVar.println(message);

            }
            server_message = inputVar.readLine();
            System.out.print("Server : " + server_message + "\n");


        }
        socket.close();
        inputVar.close();
        outVar.close();
        stdin.close();
    }

}