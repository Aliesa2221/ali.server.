import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.StringTokenizer;

public class ClientHandler extends Thread {
    private Socket client;
    private BufferedReader reader;
    private PrintWriter writer;
    private server messageServer;

    public ClientHandler(Socket socket,server messageServer) throws IOException {
        this.client = socket;
        this.reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        this.writer = new PrintWriter(socket.getOutputStream(), true);
        this.messageServer = messageServer;
    }

    @Override
    public void run() {

        String data_recv;
        
            try {
                while(true) {

                    if ((data_recv = reader.readLine()) != null) {

                        System.out.println(data_recv);
                        StringTokenizer st1 ;
                        String b1 = "";
                        String client_num = "";
                        String sent_message = "";
                        if (data_recv.equals("a")) {
                            String message = "";// Send the message to all other clients.
                            for (int i = 0; i < messageServer.clientHandlers.size(); i++) {
                                message += "Client " + i;
                                message += ",";
                            }
                            writer.println(message);
                        } else if (data_recv.equals("BYE")) {
                            // Kick the client and disconnect.
                            messageServer.UnsubscribeClient(this);
                            client.close();
                            break;
                        } else {


                            st1 = new StringTokenizer(data_recv, ",");
                            b1 = st1.nextToken();
                            if (b1.equals("c")) {
                                client_num = st1.nextToken();
                                sent_message = st1.nextToken();

                            } else if (b1.equals("d")) {
                                sent_message = st1.nextToken();
                            }
                        }
                        if (b1.equals("c")) {
                            for (int i = 0; i < messageServer.clientHandlers.size(); i++) {
                               if(i==Integer.parseInt(client_num))
                               {
                                   messageServer.clientHandlers.get(i).sendMessage(sent_message);
                               }
                            }

                        } else if (b1.equals("d")) {
                            messageServer.sendMessageToAll(sent_message);

                        }


                    }
                }
            }
            catch (IOException ioe) {
                ioe.printStackTrace();
                try {
                    client.close();
                }
                catch (IOException ioe1) {
                    ioe1.printStackTrace();
                }
            }

        try {
            client.close();
        }
        catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    public void sendMessage(String message) {
        writer.println("message arriving:" + message);
    }


}