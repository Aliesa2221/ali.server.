import java.io.IOException;

public class Source {
    public static void main(String args[]) throws Exception  {


            server messageServer = new server(5000);

            try  {
                messageServer.start();
            }
            catch (IOException ioe) {
                ioe.printStackTrace();
            }

    }
}