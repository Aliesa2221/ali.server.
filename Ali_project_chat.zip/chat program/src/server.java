

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;

public class server {
    private int port;
    private ServerSocket serverSocket;
    public LinkedList<ClientHandler> clientHandlers = new LinkedList<>();

    public server(int port) {
        this.port = port;
    }

    public void start() throws IOException {
        serverSocket = new ServerSocket(port);



        while(true)
        {
            Socket client = serverSocket.accept();
            System.out.println("A client has connected.\n");

            ClientHandler ch = new ClientHandler(client, this);
            clientHandlers.add(ch);
            ch.start();
        }
    }


    public long getClientCount() {
        return clientHandlers.size();
    }

    public void sendMessageToAll(String message) {
      for(int i =0;i<clientHandlers.size();i++)
      {
                clientHandlers.get(i).sendMessage(message);

      }
    }

    public void UnsubscribeClient(ClientHandler client) {
        clientHandlers.remove(client);
        client.interrupt();
    }
}