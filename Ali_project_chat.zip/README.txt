First Of all run the server program as it should be run first
The client side should then be run, the clients can be as much as possible and once
the client has run, it gets connected to the server

Note:
if you cannot see a message that is supposed to arrive at the client side, 
it is because the program is stuck at choosing an option so just choose option 'a' and 
then you will see the message receieved below as the recv and send statements are inorder
